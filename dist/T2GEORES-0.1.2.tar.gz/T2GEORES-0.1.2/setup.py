from distutils.core import setup

setup(
    name='T2GEORES',
    version='0.1.2',
    packages=['T2GEORES',],
    license='MIT',
    author='Erick Jiménez',
    author_email="erick@grogtp.is",
    long_description=open('README.txt').read(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Development Status :: 3 - Alpha",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires=[
        'pandas==1.1.3',
        'numpy>=1.14.5',
        'matplotlib>=3.3.2',
        'iapws>=1.5.2',
		'scipy>=1.5.3'
    ],
)